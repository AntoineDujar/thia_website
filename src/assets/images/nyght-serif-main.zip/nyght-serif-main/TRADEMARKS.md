NYGHT SERIF is a trademark of Maksym Kobuzan (2023).
